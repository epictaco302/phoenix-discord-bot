module.exports = {
	name: 'bruh',
	description: 'bruh',
	execute(message) {
		message.channel.send('moment');
	},
};